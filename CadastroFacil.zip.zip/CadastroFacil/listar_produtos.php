<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title></title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://kit.fontawesome.com/864a97e503.js" crossorigin="anonymous"></script>
        
        <style type="text/css">

            #tamanhoContainer{
                width: 500px;
            }

        </style>

    </head>
   <body style="background-color: rgb(181, 217, 255);">
    
    <div class="container" style="margin-top: 40px;">
        <h3>Lista de Produtos</h3>
        <br/>
        <a href="index.php" role="button" class="btn btn-primary btn-sm">Voltar</a>
        <br>
    
            <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">CÓD</th>
                <th scope="col">NOME DO PRODUTO</th>
                <th scope="col">CATEGORIA</th>
                <th scope="col">QUANTIDADE</th>
                <th scope="col">FORNECEDOR</th>
                <th scope="col">AÇÕES</th>
              </tr>
            </thead>
            <tbody>
              
                    
                    <a class="btn btn-primary btn-sm" href="#" role="button"><i class="fa-solid fa-magnifying-glass"></i>&nbsp;Localizar</a>
                    <a class="btn btn-warning btn-sm" href="#" role="button"><i class="fa-regular fa-pen-to-square"></i>&nbsp;Editar</a>
                    <a class="btn btn-outline-danger btn-sm" href="#" role="button"><i class="fa-regular fa-trash-can"></i>&nbsp;Excluir</a>
                </td>
              </tr>
    
              </tr>
            </tbody>
          </table>

    </div>
    
    
    </body>
</html>